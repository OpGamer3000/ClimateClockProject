#include "Ducos1a.h"

Ducos1a_t Ducos1a;