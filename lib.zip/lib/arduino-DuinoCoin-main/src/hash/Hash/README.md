# Arduino-SHA-1-Hash

This library is imported from [Arduino-SHA-1-Hash](https://github.com/mr-glt/Arduino-SHA-1-Hash).

## License

This library is [licensed](LICENSE) under the `GNU LESSER GENERAL PUBLIC LICENSE`.